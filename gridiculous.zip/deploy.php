<?php
$user = 'cbavota';
$key = md5( $user );

function cmd( $cmd ) {
	$result = shell_exec( $cmd );
	error_log( $result );
}

if ( $_POST['payload'] && $key == $_GET['key'] ) {
	error_log( $_POST['payload'] );
	$payload = json_decode( stripcslashes( $_POST['payload'] ) );

	if ( 'https://bitbucket.org' == $payload->canon_url && $user == $payload->user ) {

		$repo = $payload->repository->slug;
		$path = dirname( __FILE__ ) . '/';

		if ( ! file_exists( $path ) ) {
			if ( mkdir( $path, 0755 ) ) {
				chdir( $path );
				cmd( 'git init' );
				cmd( 'git remote add origin git@bitbucket.org:' . $user . '/' . $repo . '.git' );
				cmd( 'git pull origin master' );
			}
		}

		if ( is_dir( $path ) ) {
			chdir( $path );
			cmd( 'git reset --hard HEAD' );
			cmd( 'git pull origin master' );
		}
	}

	die();
} else {
	echo 'Nothing to see here!';
}